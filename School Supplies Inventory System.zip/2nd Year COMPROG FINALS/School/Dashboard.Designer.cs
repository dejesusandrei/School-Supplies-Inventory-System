﻿namespace School
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
            panel2 = new Panel();
            label1 = new Label();
            label2 = new Label();
            panel3 = new Panel();
            label4 = new Label();
            lblTotalItem = new Label();
            panel4 = new Panel();
            label5 = new Label();
            lblTotalCateg = new Label();
            dataGridView1 = new DataGridView();
            label9 = new Label();
            panel1 = new Panel();
            panel5 = new Panel();
            label3 = new Label();
            lblCategory = new Label();
            lblProducts = new Label();
            lblDashboard = new Label();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel2
            // 
            panel2.BackColor = Color.Teal;
            panel2.Controls.Add(label1);
            panel2.Location = new Point(195, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(1157, 41);
            panel2.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Lucida Sans", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(19, 9);
            label1.Name = "label1";
            label1.Size = new Size(545, 26);
            label1.TabIndex = 3;
            label1.Text = "SCHOOL SUPPLIES INVENTORY ITEMS SYSTEM";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Lucida Sans", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.DarkSlateGray;
            label2.Location = new Point(261, 62);
            label2.Name = "label2";
            label2.Size = new Size(181, 23);
            label2.TabIndex = 26;
            label2.Text = "Welcome Admin!";
            // 
            // panel3
            // 
            panel3.BackColor = Color.Teal;
            panel3.Controls.Add(label4);
            panel3.Controls.Add(lblTotalItem);
            panel3.Font = new Font("Lucida Sans", 9F);
            panel3.Location = new Point(261, 100);
            panel3.Name = "panel3";
            panel3.Size = new Size(206, 136);
            panel3.TabIndex = 27;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Lucida Sans", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.White;
            label4.Location = new Point(46, 93);
            label4.Name = "label4";
            label4.Size = new Size(109, 23);
            label4.TabIndex = 29;
            label4.Text = "Total Item";
            // 
            // lblTotalItem
            // 
            lblTotalItem.AutoSize = true;
            lblTotalItem.Font = new Font("Lucida Sans", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTotalItem.ForeColor = Color.White;
            lblTotalItem.Location = new Point(67, 26);
            lblTotalItem.Name = "lblTotalItem";
            lblTotalItem.Size = new Size(66, 42);
            lblTotalItem.TabIndex = 28;
            lblTotalItem.Text = "10";
            // 
            // panel4
            // 
            panel4.BackColor = Color.Teal;
            panel4.Controls.Add(label5);
            panel4.Controls.Add(lblTotalCateg);
            panel4.Font = new Font("Lucida Sans", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            panel4.ForeColor = Color.White;
            panel4.Location = new Point(497, 100);
            panel4.Name = "panel4";
            panel4.Size = new Size(206, 136);
            panel4.TabIndex = 30;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Lucida Sans", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(19, 93);
            label5.Name = "label5";
            label5.Size = new Size(171, 23);
            label5.TabIndex = 29;
            label5.Text = "Total Categories";
            // 
            // lblTotalCateg
            // 
            lblTotalCateg.AutoSize = true;
            lblTotalCateg.Font = new Font("Lucida Sans", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTotalCateg.Location = new Point(74, 26);
            lblTotalCateg.Name = "lblTotalCateg";
            lblTotalCateg.Size = new Size(66, 42);
            lblTotalCateg.TabIndex = 28;
            lblTotalCateg.Text = "10";
            // 
            // dataGridView1
            // 
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.BackgroundColor = Color.Honeydew;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.GridColor = Color.DarkSlateGray;
            dataGridView1.Location = new Point(261, 296);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(960, 261);
            dataGridView1.TabIndex = 31;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Lucida Sans", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.DarkSlateGray;
            label9.Location = new Point(261, 257);
            label9.Name = "label9";
            label9.Size = new Size(111, 26);
            label9.TabIndex = 32;
            label9.Text = "Item List";
            // 
            // panel1
            // 
            panel1.BackColor = Color.DarkSlateGray;
            panel1.Controls.Add(panel5);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(lblCategory);
            panel1.Controls.Add(lblProducts);
            panel1.Controls.Add(lblDashboard);
            panel1.Location = new Point(-4, -1);
            panel1.Name = "panel1";
            panel1.Size = new Size(212, 690);
            panel1.TabIndex = 33;
            // 
            // panel5
            // 
            panel5.BackgroundImage = (Image)resources.GetObject("panel5.BackgroundImage");
            panel5.BackgroundImageLayout = ImageLayout.Zoom;
            panel5.Location = new Point(8, 1);
            panel5.Name = "panel5";
            panel5.Size = new Size(201, 190);
            panel5.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Lucida Sans", 10.8F, FontStyle.Bold);
            label3.ForeColor = Color.WhiteSmoke;
            label3.Location = new Point(38, 325);
            label3.Name = "label3";
            label3.Size = new Size(103, 21);
            label3.TabIndex = 4;
            label3.Text = "➜] Logout";
            label3.Click += label3_Click;
            // 
            // lblCategory
            // 
            lblCategory.AutoSize = true;
            lblCategory.Font = new Font("Lucida Sans", 10.8F, FontStyle.Bold);
            lblCategory.ForeColor = Color.WhiteSmoke;
            lblCategory.Location = new Point(38, 283);
            lblCategory.Name = "lblCategory";
            lblCategory.Size = new Size(124, 21);
            lblCategory.TabIndex = 2;
            lblCategory.Text = "🗂️ Category";
            lblCategory.Click += lblCategory_Click_1;
            // 
            // lblProducts
            // 
            lblProducts.AutoSize = true;
            lblProducts.Font = new Font("Lucida Sans", 10.8F, FontStyle.Bold);
            lblProducts.ForeColor = Color.WhiteSmoke;
            lblProducts.Location = new Point(38, 242);
            lblProducts.Name = "lblProducts";
            lblProducts.Size = new Size(120, 21);
            lblProducts.TabIndex = 1;
            lblProducts.Text = "📦 Products";
            lblProducts.Click += lblProducts_Click_1;
            // 
            // lblDashboard
            // 
            lblDashboard.AutoSize = true;
            lblDashboard.Font = new Font("Lucida Sans", 10.8F, FontStyle.Bold);
            lblDashboard.ForeColor = Color.WhiteSmoke;
            lblDashboard.Location = new Point(38, 203);
            lblDashboard.Name = "lblDashboard";
            lblDashboard.Size = new Size(139, 21);
            lblDashboard.TabIndex = 0;
            lblDashboard.Text = "📊 Dashboard";
            // 
            // Dashboard
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.MintCream;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1262, 602);
            Controls.Add(panel1);
            Controls.Add(label9);
            Controls.Add(dataGridView1);
            Controls.Add(panel4);
            Controls.Add(panel3);
            Controls.Add(label2);
            Controls.Add(panel2);
            Name = "Dashboard";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Dashboard";
            Load += Dashboard_Load;
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Panel panel2;
        private Label label1;
        private Label label2;
        private Panel panel3;
        private Label label4;
        private Label lblTotalItem;
        private Panel panel4;
        private Label label5;
        private Label lblTotalCateg;
        private DataGridView dataGridView1;
        private Label label9;
        private Panel panel1;
        private Label lblCategory;
        private Label lblProducts;
        private Label lblDashboard;
        private Label label3;
        private Panel panel5;
    }
}