﻿namespace School
{
    partial class Products
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Products));
            textBox1 = new TextBox();
            label1 = new Label();
            comboBox1 = new ComboBox();
            label2 = new Label();
            label3 = new Label();
            textBox2 = new TextBox();
            label4 = new Label();
            textBox3 = new TextBox();
            label5 = new Label();
            textBox4 = new TextBox();
            label6 = new Label();
            textBox5 = new TextBox();
            btnEdit = new Button();
            btnAdd = new Button();
            btnDelete = new Button();
            btnCancel = new Button();
            btnSave = new Button();
            dataGridView1 = new DataGridView();
            label8 = new Label();
            panel1 = new Panel();
            panel5 = new Panel();
            label9 = new Label();
            lblCategory = new Label();
            lblProducts = new Label();
            lblDashboard = new Label();
            panel2 = new Panel();
            label7 = new Label();
            panel3 = new Panel();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            SuspendLayout();
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.FromArgb(192, 255, 192);
            textBox1.Location = new Point(266, 159);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(303, 27);
            textBox1.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Lucida Sans", 10.2F);
            label1.ForeColor = Color.Transparent;
            label1.Location = new Point(12, 15);
            label1.Name = "label1";
            label1.Size = new Size(101, 19);
            label1.TabIndex = 1;
            label1.Text = "Product Id:";
            // 
            // comboBox1
            // 
            comboBox1.BackColor = Color.FromArgb(192, 255, 192);
            comboBox1.ForeColor = Color.Black;
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(266, 301);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(303, 28);
            comboBox1.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Lucida Sans", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(12, 155);
            label2.Name = "label2";
            label2.Size = new Size(158, 19);
            label2.TabIndex = 3;
            label2.Text = "Product Category:";
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Lucida Sans", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Transparent;
            label3.Location = new Point(12, 79);
            label3.Name = "label3";
            label3.Size = new Size(131, 19);
            label3.TabIndex = 5;
            label3.Text = "Product Name:";
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.FromArgb(192, 255, 192);
            textBox2.Location = new Point(266, 229);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(303, 27);
            textBox2.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Lucida Sans", 10.2F);
            label4.ForeColor = Color.White;
            label4.Location = new Point(382, 15);
            label4.Name = "label4";
            label4.Size = new Size(124, 19);
            label4.TabIndex = 7;
            label4.Text = "Product Price:";
            // 
            // textBox3
            // 
            textBox3.BackColor = Color.FromArgb(192, 255, 192);
            textBox3.Location = new Point(636, 159);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(291, 27);
            textBox3.TabIndex = 6;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Lucida Sans", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(382, 79);
            label5.Name = "label5";
            label5.Size = new Size(129, 19);
            label5.TabIndex = 9;
            label5.Text = "Product Stock:";
            // 
            // textBox4
            // 
            textBox4.BackColor = Color.FromArgb(192, 255, 192);
            textBox4.Location = new Point(636, 229);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(291, 27);
            textBox4.TabIndex = 8;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Lucida Sans", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.White;
            label6.Location = new Point(382, 155);
            label6.Name = "label6";
            label6.Size = new Size(196, 19);
            label6.TabIndex = 11;
            label6.Text = "Product Manufacturer:";
            // 
            // textBox5
            // 
            textBox5.BackColor = Color.FromArgb(192, 255, 192);
            textBox5.Location = new Point(636, 301);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(291, 27);
            textBox5.TabIndex = 10;
            // 
            // btnEdit
            // 
            btnEdit.BackColor = Color.WhiteSmoke;
            btnEdit.Font = new Font("Lucida Sans", 10.8F, FontStyle.Bold);
            btnEdit.ForeColor = Color.Black;
            btnEdit.Location = new Point(557, 611);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(151, 42);
            btnEdit.TabIndex = 12;
            btnEdit.Text = "EDIT";
            btnEdit.UseVisualStyleBackColor = false;
            btnEdit.Click += btnEdit_Click;
            btnEdit.MouseLeave += btnEdit_MouseLeave;
            btnEdit.MouseHover += btnEdit_MouseHover;
            // 
            // btnAdd
            // 
            btnAdd.BackColor = Color.WhiteSmoke;
            btnAdd.Font = new Font("Lucida Sans", 10.8F, FontStyle.Bold);
            btnAdd.ForeColor = Color.Black;
            btnAdd.Location = new Point(733, 611);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(194, 42);
            btnAdd.TabIndex = 13;
            btnAdd.Text = "ADD PRODUCT";
            btnAdd.UseVisualStyleBackColor = false;
            btnAdd.Click += button1_Click;
            btnAdd.MouseLeave += btnAdd_MouseLeave;
            btnAdd.MouseHover += btnAdd_MouseHover;
            // 
            // btnDelete
            // 
            btnDelete.BackColor = Color.WhiteSmoke;
            btnDelete.Font = new Font("Lucida Sans", 10.8F, FontStyle.Bold);
            btnDelete.ForeColor = Color.Black;
            btnDelete.Location = new Point(949, 611);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(151, 42);
            btnDelete.TabIndex = 14;
            btnDelete.Text = "DELETE";
            btnDelete.UseVisualStyleBackColor = false;
            btnDelete.Click += btnDelete_Click;
            btnDelete.MouseLeave += btnDelete_MouseLeave;
            btnDelete.MouseHover += btnDelete_MouseHover;
            // 
            // btnCancel
            // 
            btnCancel.BackColor = Color.WhiteSmoke;
            btnCancel.Font = new Font("Lucida Sans", 10.8F, FontStyle.Bold);
            btnCancel.ForeColor = Color.Black;
            btnCancel.Location = new Point(952, 254);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(151, 42);
            btnCancel.TabIndex = 15;
            btnCancel.Text = "CANCEL";
            btnCancel.UseVisualStyleBackColor = false;
            btnCancel.Click += btnCancel_Click;
            btnCancel.MouseLeave += btnCancel_MouseLeave;
            btnCancel.MouseHover += btnCancel_MouseHover;
            // 
            // btnSave
            // 
            btnSave.BackColor = Color.WhiteSmoke;
            btnSave.Font = new Font("Lucida Sans", 10.8F, FontStyle.Bold);
            btnSave.ForeColor = Color.Black;
            btnSave.Location = new Point(952, 184);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(151, 42);
            btnSave.TabIndex = 16;
            btnSave.Text = "SAVE";
            btnSave.UseVisualStyleBackColor = false;
            btnSave.Click += btnSave_Click;
            btnSave.MouseLeave += btnSave_MouseLeave;
            btnSave.MouseHover += btnSave_MouseHover;
            // 
            // dataGridView1
            // 
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.BackgroundColor = Color.White;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(266, 366);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(837, 200);
            dataGridView1.TabIndex = 17;
            dataGridView1.CellClick += dataGridView1_CellClick;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Lucida Sans", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.DarkSlateGray;
            label8.Location = new Point(557, 74);
            label8.Name = "label8";
            label8.Size = new Size(271, 26);
            label8.TabIndex = 4;
            label8.Text = "Products Management";
            // 
            // panel1
            // 
            panel1.BackColor = Color.DarkSlateGray;
            panel1.Controls.Add(panel5);
            panel1.Controls.Add(label9);
            panel1.Controls.Add(lblCategory);
            panel1.Controls.Add(lblProducts);
            panel1.Controls.Add(lblDashboard);
            panel1.Location = new Point(0, 1);
            panel1.Name = "panel1";
            panel1.Size = new Size(212, 690);
            panel1.TabIndex = 28;
            // 
            // panel5
            // 
            panel5.BackgroundImage = (Image)resources.GetObject("panel5.BackgroundImage");
            panel5.BackgroundImageLayout = ImageLayout.Zoom;
            panel5.Location = new Point(6, 8);
            panel5.Name = "panel5";
            panel5.Size = new Size(201, 190);
            panel5.TabIndex = 31;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Lucida Sans", 10.8F, FontStyle.Bold);
            label9.ForeColor = Color.WhiteSmoke;
            label9.Location = new Point(36, 324);
            label9.Name = "label9";
            label9.Size = new Size(103, 21);
            label9.TabIndex = 30;
            label9.Text = "➜] Logout";
            label9.Click += label9_Click;
            // 
            // lblCategory
            // 
            lblCategory.AutoSize = true;
            lblCategory.Font = new Font("Lucida Sans", 10.8F, FontStyle.Bold);
            lblCategory.ForeColor = Color.WhiteSmoke;
            lblCategory.Location = new Point(36, 286);
            lblCategory.Name = "lblCategory";
            lblCategory.Size = new Size(124, 21);
            lblCategory.TabIndex = 2;
            lblCategory.Text = "🗂️ Category";
            lblCategory.Click += lblCategory_Click_1;
            // 
            // lblProducts
            // 
            lblProducts.AutoSize = true;
            lblProducts.Font = new Font("Lucida Sans", 10.8F, FontStyle.Bold);
            lblProducts.ForeColor = Color.WhiteSmoke;
            lblProducts.Location = new Point(36, 246);
            lblProducts.Name = "lblProducts";
            lblProducts.Size = new Size(120, 21);
            lblProducts.TabIndex = 1;
            lblProducts.Text = "📦 Products";
            // 
            // lblDashboard
            // 
            lblDashboard.AutoSize = true;
            lblDashboard.Font = new Font("Lucida Sans", 10.8F, FontStyle.Bold);
            lblDashboard.ForeColor = Color.WhiteSmoke;
            lblDashboard.Location = new Point(36, 207);
            lblDashboard.Name = "lblDashboard";
            lblDashboard.Size = new Size(139, 21);
            lblDashboard.TabIndex = 0;
            lblDashboard.Text = "📊 Dashboard";
            lblDashboard.Click += lblDashboard_Click_1;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Teal;
            panel2.Controls.Add(label7);
            panel2.Location = new Point(211, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(1157, 41);
            panel2.TabIndex = 29;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Lucida Sans", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.White;
            label7.Location = new Point(208, 9);
            label7.Name = "label7";
            label7.Size = new Size(545, 26);
            label7.TabIndex = 3;
            label7.Text = "SCHOOL SUPPLIES INVENTORY ITEMS SYSTEM";
            // 
            // panel3
            // 
            panel3.BackColor = Color.DarkSlateGray;
            panel3.Controls.Add(label4);
            panel3.Controls.Add(label5);
            panel3.Controls.Add(label6);
            panel3.Controls.Add(label1);
            panel3.Controls.Add(label3);
            panel3.Controls.Add(label2);
            panel3.Location = new Point(243, 121);
            panel3.Name = "panel3";
            panel3.Size = new Size(889, 464);
            panel3.TabIndex = 30;
            // 
            // Products
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.MintCream;
            BackgroundImageLayout = ImageLayout.Center;
            ClientSize = new Size(1170, 692);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(label8);
            Controls.Add(dataGridView1);
            Controls.Add(btnSave);
            Controls.Add(btnCancel);
            Controls.Add(btnDelete);
            Controls.Add(btnAdd);
            Controls.Add(btnEdit);
            Controls.Add(textBox5);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(comboBox1);
            Controls.Add(textBox1);
            Controls.Add(panel3);
            Name = "Products";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Products";
            Load += Products_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox1;
        private Label label1;
        private ComboBox comboBox1;
        private Label label2;
        private Label label3;
        private TextBox textBox2;
        private Label label4;
        private TextBox textBox3;
        private Label label5;
        private TextBox textBox4;
        private Label label6;
        private TextBox textBox5;
        private Button btnEdit;
        private Button btnAdd;
        private Button btnDelete;
        private Button btnCancel;
        private Button btnSave;
        private DataGridView dataGridView1;
        private Label label8;
        private Panel panel1;
        private Label lblCategory;
        private Label lblProducts;
        private Label lblDashboard;
        private Panel panel2;
        private Label label7;
        private Label label9;
        private Panel panel3;
        private Panel panel5;
    }
}